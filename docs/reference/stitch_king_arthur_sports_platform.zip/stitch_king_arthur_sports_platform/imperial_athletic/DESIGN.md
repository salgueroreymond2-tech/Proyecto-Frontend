---
name: Imperial Athletic
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#4d444c'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f1f1f1'
  outline: '#7e747c'
  outline-variant: '#d0c3cc'
  surface-tint: '#77517a'
  primary: '#19001f'
  on-primary: '#ffffff'
  primary-container: '#341439'
  on-primary-container: '#a47ba6'
  inverse-primary: '#e6b8e7'
  secondary: '#974800'
  on-secondary: '#ffffff'
  secondary-container: '#fd8119'
  on-secondary-container: '#5f2b00'
  tertiary: '#000d06'
  on-tertiary: '#ffffff'
  tertiary-container: '#002718'
  on-tertiary-container: '#009c6b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd6ff'
  primary-fixed-dim: '#e6b8e7'
  on-primary-fixed: '#2e0e33'
  on-primary-fixed-variant: '#5d3a61'
  secondary-fixed: '#ffdbc7'
  secondary-fixed-dim: '#ffb689'
  on-secondary-fixed: '#311300'
  on-secondary-fixed-variant: '#733500'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-numeric:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-badge:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '800'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4.5rem
---

## Brand & Style

This design system establishes an elite SportTech aesthetic tailored for competitive streaming, tournament wagering, and real-time athletic analytics. The brand projects regality, athletic precision, and high-stakes exclusivity. It balances the tension between an airy, ultra-clean consumption canvas and dramatic, high-performance command surfaces.

The visual style combines modern sports analytics dashboard discipline with high-contrast luxury:
- **Canvas vs. Cockpit Structure:** Content sits on an expansive, light grey base that feels deliberate and clinical, while actionable modules, hero scorecards, and media surfaces plunge into an uncompromising Imperial Purple.
- **Electric Precision:** High-chroma energetic orange punctuates key athletic inflection points, live markers, call-to-actions, and live scoring.
- **Prestige Signals:** Metallic micro-accents, crisp translucent borders, and status-driven metric pills evoke premium tier membership and high-tier competitive play.

## Colors

The palette relies on deliberate contrast hierarchies across two visual states: light-mode canvas foundations and dark imperial module surfaces.

### Primary Color: Imperial Purple (`#341439`)
The bedrock of elite authority. Used for header shells, tournament bracket containers, media cards, primary analytical cards, and global navigation headers. On the `#F7F7F7` base canvas, text and high-priority headings render in `#341439`.

### Secondary Color: Vibrant Kinetic Orange (`#EA7301`)
The tournament activator. Reserved for decisive interactive triggers: Primary CTAs, active live match indicators, live odds changes, prestige point badges (`1,250 PTS`), and focus highlights. Never wash large surfaces in this color; it acts strictly as an energetic burst.

### Tertiary & Semantic Accents
- **Active Status Green (`#10B981`):** Applied to active membership badges (e.g., 'Cliente Activo'), live stream uptime, and verified transaction receipts.
- **Muted Violet Overlay (`#9B82A6`):** Secondary text, subtle borders, and inactive icons on Imperial Purple containers.
- **Surface Elevation (`#421C48`):** Hover states, nested rows, and floating panels within Imperial Purple modules.

### Neutral: Light Gray (`#F7F7F7`)
The global viewport base. Prevents athletic visual fatigue and contrasts sharply against deep purple tournament modules. Secondary neutral dividers on canvas utilize `#E5E5E8`.

## Typography

The pairing between Plus Jakarta Sans and Inter balances competitive dynamic authority with precise data consumption:

- **Headlines & Metric Callouts (Plus Jakarta Sans):** Set with geometric precision and tight letter tracking. Headings command tournament matchups, live broadcast clocks, and team counters. Bold/ExtraBold cuts deliver athletic confidence.
- **Interface & Analytical Data (Inter):** Deployed across match tables, bet slips, telemetry data, and rules copy. Its neutral glyphs ensure rapid scanning of live statistics without visual noise.
- **Container Inversion Rules:**
  - On the `#F7F7F7` root canvas, headings and primary body sit in `#341439`, with secondary labels in `#6B5E70`.
  - Inside `#341439` Imperial Purple modules, text switches to pure `#FFFFFF` for primary titles, and `#9B82A6` for supporting statistics, metadata, and timestamps.

## Layout & Spacing

The layout is built on a responsive 12-column dynamic grid designed for high-density sports media and multi-table bracket tracking:

- **Desktop (1200px+):** 12 columns with `1.5rem` gutters and max container constraint of `1440px`. Accommodates side-by-side live video viewports, live score telemetry bars, and interactive bracket trees. Outer margin is `3rem`.
- **Tablet (768px – 1199px):** 8 columns with `1.25rem` gutters and `2rem` outer margin. Cards drop secondary metadata; bet slips shift to slide-over floating drawers.
- **Mobile (< 768px):** 4 columns with `1rem` gutters and `1rem` outer margin. Match cards fold to full-width vertically stacked layouts.

### Spacing Cadence
Component internals follow a disciplined rhythmic increment:
- Tight metadata and badge gaps use `space-2xs` (4px) and `space-xs` (8px).
- Input padding, button heights, and bracket nodes space by `space-sm` (12px) and `space-md` (16px).
- Internal module padding strictly maintains `space-lg` (24px) to preserve clean athletic legibility.

## Elevation & Depth

This system avoids generic drop shadows, utilizing low-key ambient purple-tinted depth and sharp edge definition to simulate tactical glass and cockpit instrument panels:

- **Base Canvas:** Flat `#F7F7F7`, zero elevation.
- **Level 1 (Imperial Modules & Cards):** Background `#341439`, edged with a crisp, low-opacity boundary (`1px solid rgba(255, 255, 255, 0.08)`). Elevated above the light canvas via a subtle, diffused cast: `0 12px 32px -8px rgba(52, 20, 57, 0.16)`.
- **Level 2 (Active Tournament Panels & Pay-Per-View Players):** Background `#341439`, highlighted with an energetic hairline accent border (`1px solid rgba(234, 115, 1, 0.35)`) and dual ambient glow: `0 8px 24px -4px rgba(52, 20, 57, 0.32), 0 0 16px -2px rgba(234, 115, 1, 0.15)`.
- **Level 3 (Modals, Checkout Drawers, Dynamic Odds Overlays):** Background `#2A0E2E` with an inner border of `1px solid rgba(255, 255, 255, 0.14)` and a commanding floor shadow: `0 24px 48px -12px rgba(18, 5, 20, 0.5)`.

## Shapes

The design system standardizes on a calibrated **12px (`0.75rem`) border radius** across primary interactive and data components:

- **Containers & Tournament Cards:** Hardwired to `12px` to balance modern digital software feel with sports screen rigor.
- **Buttons & Input Controls:** Aligned to `8px` or `12px` matching card geometry.
- **Data Pills & Status Badges:** Fully circular / pill (`9999px`) to create functional differentiation between layout frames and contextual states.

## Components

### Buttons
- **Primary Action (CTA):** Solid Vibrant Orange (`#EA7301`) background with crisp white text (`#FFFFFF`, Plus Jakarta Sans, 700 weight). 12px radius, zero border. Hover introduces a high-energy bloom (`box-shadow: 0 4px 16px rgba(234, 115, 1, 0.4)`) and a translateY(-1px) micro-interaction.
- **Imperial Secondary:** Solid Purple (`#341439`) on light canvas, or Elevated Purple (`#481E50`) inside purple modules. Border: `1px solid rgba(255, 255, 255, 0.15)`. Text: `#FFFFFF`.
- **Ghost Action:** Transparent background, `1px solid rgba(52, 20, 57, 0.2)` on light ground; `1px solid rgba(234, 115, 1, 0.4)` when contextual to live streams.

### Status Badges & Prestige Indicators
- **'Cliente Activo' Badge:** Pill-shaped (`rounded-full`), `padding: 4px 10px`. Background is a deep translucent emerald (`rgba(16, 185, 129, 0.12)`), text is `#10B981`, with a `1px solid rgba(16, 185, 129, 0.25)` rim. Includes a 6px pulsing green indicator dot.
- **Prestige Points ('1,250 PTS'):** High-visibility dark pill. Background: `#250D2A`. Border: `1px solid rgba(234, 115, 1, 0.4)`. Text: `#EA7301`, 800 weight, uppercase tracking. Accompanied by a subtle gold or orange jewel-cut icon.

### Tournament Cards & Module Shells
- Standardized at `12px` radius.
- Default surface is Imperial Purple (`#341439`).
- Card content hierarchy:
  1. Top utility row with League Tag + Live/Status Pill + Prestige Points cost.
  2. Main body: High-contrast competitor names (`#FFFFFF`), live odds or score split, followed by stream telemetry.
  3. Action tier: Divided by a translucent border (`1px solid rgba(255, 255, 255, 0.08)`), featuring direct Access/Buy passes in `#EA7301`.

### Form Inputs & Selectors
- **Light Context:** Crisp white field on `#F7F7F7` canvas, `1px solid #E2E2E6`, text in `#341439`. Active focus: `border-color: #EA7301`, with an orange ambient ring (`rgba(234, 115, 1, 0.15)`).
- **Imperial Context:** `#280C2C` fill, border `1px solid rgba(255, 255, 255, 0.12)`, text `#FFFFFF`, placeholder `#9B82A6`. Focus transitions border to `#EA7301`.

### Checkboxes & Segmented Toggles
- Checkbox dimensions are 20×20px with a 4px corner radius. Unchecked: `1.5px solid rgba(255, 255, 255, 0.3)` on purple. Checked: Solid `#EA7301` background with a bold white checkmark.
- Segmented bracket switchers use Imperial Purple shells with high-contrast sliding indicator tabs in Vibrant Orange.